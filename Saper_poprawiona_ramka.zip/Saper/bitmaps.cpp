#include "allegro.h"
#include "bitmaps.h"

BITMAP *standard_block = NULL;
BITMAP *zero_block = NULL;
BITMAP *one_block = NULL;
BITMAP *two_block = NULL;
BITMAP *three_block = NULL;
BITMAP *four_block = NULL;
BITMAP *five_block = NULL;
BITMAP *six_block = NULL;
BITMAP *seven_block = NULL;
BITMAP *eight_block = NULL;
BITMAP *bomb_block = NULL;
BITMAP *bomb_2_block = NULL);
BITMAP *bomb_3_block = NULL;
BITMAP *flag_block = NULL;

#ifndef settings_H_INCLUDED
#define settings_H_INCLUDED

int starting_x=25;//pozycja startowa planszy
int starting_y=75;//pozycja startowa planszy
int block_size=25;//rozmiar pojedyńczego bloku
int block_count=20;//liczba blokow w wierszy/kolumnie (na ten moment dostepne jedynie kwadratowe plansze)
int ilosc_bomb=20;
int test=1;//Opcja od odsłania całej mapy

#endif // settings_H_INCLUDED

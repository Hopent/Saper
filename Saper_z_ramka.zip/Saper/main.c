/*Allegro 4.2.2 Syntax*/
// https://phoxis.org/2009/02/13/allegro-422/
// Dostêp: 2017-10-29
#include <stdio.h>
#include <allegro.h>
#include "settings.h"
#include "bitmaps.h"
#include <time.h>
#include <unistd.h>


#define RED makecol(255,0,0)
#define GREEN makecol(0,255,0)
#define BLUE makecol(0,0,255)
#define BLACK makecol(0,0,0)
#define WHITE makecol(255,255,255)
#define BLACK makecol(0,0,0)

void wyzeruj_tablice(int *array,int block_count)
{
int i;
    for(i=0; i<block_count*block_count; i++)
    {
        array[i]=0;
    }
}

void sprawdz_plansze(int *array,int block_count){
    int index;
    for(index=1;index<(block_count*block_count)+1;index++){
      if(array[index]==0){
        int liczba_min=0;
            //lewy_gorny
            if((index-block_count-1)>0&&(index%block_count)!=1){
                if(array[index-block_count-1]==15){
                    liczba_min++;
                }
            }
            //srodek_gorny
            if((index-block_count)>0){
                if(array[index-block_count]==15){
                    liczba_min++;
                }

            }
            //prawo_gorny
            if(((index-block_count+1)>0)&&((index%block_count)!=0)){
                if(array[index-block_count+1]==15){
                    liczba_min++;
                }
            }
            //lewo_srodek
            if((index-1)>0&&(index%block_count)!=1){
                if(array[index-1]==15){
                    liczba_min++;
                }
            }
            //prawo_srodek
            if((index%block_count)!=0){
               if(array[index+1]==15){
                    liczba_min++;
                }
            }
            //lewo_dolny
            if(((index+block_count-1)<(block_count*block_count)+1)&&(index%block_count)!=1){
                if(array[index+block_count-1]==15){
                    liczba_min++;
                }
            }
            //srodek_dolny
            if((index+block_count)<(block_count*block_count)+1){
                if(array[index+block_count]==15){
                    liczba_min++;
                }
            }
            //prawo_dolny
            if(((index+block_count+1)<(block_count*block_count)+1)&&((index+block_count)%block_count!=0)){
                if(array[index+block_count+1]==15){
                    liczba_min++;
                }

            }

            array[index]=liczba_min;//zapisuje ilosc min w obrębie jednej kradki
        }
    }

}



void losuj_bomby(int *array,int ilosc_bomb,int block_count){
    int i;
    int liczba=0;
    for(i=ilosc_bomb;i>0;i--){
            liczba =1+rand()%(block_count*block_count);
        if(array[liczba]!=15){
            array[liczba]=15;
        }else{
            i++;
        }
    }
}
void odslon_kwadrat(int element,int *block_array_pointer,BITMAP *buffer,BITMAP *standard_block,BITMAP *zero_block,BITMAP *one_block,BITMAP *two_block,BITMAP *three_block,BITMAP *four_block,BITMAP *five_block,BITMAP *six_block,BITMAP *seven_block,BITMAP *eight_block,BITMAP *bomb_block,BITMAP *bomb_2_block,BITMAP *bomb_3_block,BITMAP *flag_block){
            int x = starting_x+((element-1)%block_count)*block_size;
            int y = starting_y+((element - (element-1)%block_count)/block_count)*block_size;
            if(block_array_pointer[element]==0){draw_sprite(buffer,zero_block,x,y);}
            if(block_array_pointer[element]==1){draw_sprite(buffer,one_block,x,y);}
            if(block_array_pointer[element]==2){draw_sprite(buffer,two_block,x,y);}
            if(block_array_pointer[element]==3){draw_sprite(buffer,three_block,x,y);}
            if(block_array_pointer[element]==4){draw_sprite(buffer,four_block,x,y);}
            if(block_array_pointer[element]==5){draw_sprite(buffer,five_block,x,y);}
            if(block_array_pointer[element]==6){draw_sprite(buffer,six_block,x,y);}
            if(block_array_pointer[element]==7){draw_sprite(buffer,seven_block,x,y);}
            if(block_array_pointer[element]==8){draw_sprite(buffer,eight_block,x,y);}
            if(block_array_pointer[element]==10){draw_sprite(buffer,flag_block,x,y);}
            if(block_array_pointer[element]==15){draw_sprite(buffer,bomb_block,x,y);}
            if(block_array_pointer[element]==20){draw_sprite(buffer,bomb_2_block,x,y);}
            if(block_array_pointer[element]==25){draw_sprite(buffer,bomb_3_block,x,y);}
}

void odslon_wszystko(int *block_array_pointer,BITMAP *buffer,BITMAP *standard_block,BITMAP *zero_block,BITMAP *one_block,BITMAP *two_block,BITMAP *three_block,BITMAP *four_block,BITMAP *five_block,BITMAP *six_block,BITMAP *seven_block,BITMAP *eight_block,BITMAP *bomb_block,BITMAP *bomb_2_block,BITMAP *bomb_3_block,BITMAP *flag_block){
    int i=0;int j=0;int element=0;//Tymczasowe zmienne do petli
    for(i=0;i<block_count;i++){
        for(j=0;j<block_count;j++){
            element++;
            if(block_array_pointer[element]==0){draw_sprite(buffer,zero_block,starting_x+(j*block_size),starting_y+(i*block_size));}
            if(block_array_pointer[element]==1){draw_sprite(buffer,one_block,starting_x+(j*block_size),starting_y+(i*block_size));}
            if(block_array_pointer[element]==2){draw_sprite(buffer,two_block,starting_x+(j*block_size),starting_y+(i*block_size));}
            if(block_array_pointer[element]==3){draw_sprite(buffer,three_block,starting_x+(j*block_size),starting_y+(i*block_size));}
            if(block_array_pointer[element]==4){draw_sprite(buffer,four_block,starting_x+(j*block_size),starting_y+(i*block_size));}
            if(block_array_pointer[element]==5){draw_sprite(buffer,five_block,starting_x+(j*block_size),starting_y+(i*block_size));}
            if(block_array_pointer[element]==6){draw_sprite(buffer,six_block,starting_x+(j*block_size),starting_y+(i*block_size));}
            if(block_array_pointer[element]==7){draw_sprite(buffer,seven_block,starting_x+(j*block_size),starting_y+(i*block_size));}
            if(block_array_pointer[element]==8){draw_sprite(buffer,eight_block,starting_x+(j*block_size),starting_y+(i*block_size));}
            if(block_array_pointer[element]==10){draw_sprite(buffer,flag_block,starting_x+(j*block_size),starting_y+(i*block_size));}
            if(block_array_pointer[element]==15){draw_sprite(buffer,bomb_block,starting_x+(j*block_size),starting_y+(i*block_size));}
            if(block_array_pointer[element]==20){draw_sprite(buffer,bomb_2_block,starting_x+(j*block_size),starting_y+(i*block_size));}
            if(block_array_pointer[element]==25){draw_sprite(buffer,bomb_3_block,starting_x+(j*block_size),starting_y+(i*block_size));}

        }
    }
}

void check_clicked(int element,int *block_array_pointer,BITMAP *buffer,BITMAP *standard_block,BITMAP *zero_block,BITMAP *one_block,BITMAP *two_block,BITMAP *three_block,BITMAP *four_block,BITMAP *five_block,BITMAP *six_block,BITMAP *seven_block,BITMAP *eight_block,BITMAP *bomb_block,BITMAP *bomb_2_block,BITMAP *bomb_3_block,BITMAP *flag_block){

        if(block_array_pointer[element]==15){
            block_array_pointer[element]=25;
            odslon_wszystko(block_array_pointer,buffer,standard_block,zero_block,one_block,two_block,three_block,four_block,five_block,six_block,seven_block,eight_block,bomb_block,bomb_2_block,bomb_3_block,flag_block);
            //odslon_kwadrat(element,block_array_pointer,buffer,standard_block,zero_block,one_block,two_block,three_block,four_block,five_block,six_block,seven_block,eight_block,bomb_block,bomb_2_block,bomb_3_block,flag_block);
        }
        if(block_array_pointer[element]<10){
            odslon_kwadrat(element,block_array_pointer,buffer,standard_block,zero_block,one_block,two_block,three_block,four_block,five_block,six_block,seven_block,eight_block,bomb_block,bomb_2_block,bomb_3_block,flag_block);
            block_array_pointer[element] = block_array_pointer[element]+50;
            if(block_array_pointer[element]-50==0){
                //gora
                if(element>block_count){
                     check_clicked(element-block_count,block_array_pointer,buffer,standard_block,zero_block,one_block,two_block,three_block,four_block,five_block,six_block,seven_block,eight_block,bomb_block,bomb_2_block,bomb_3_block,flag_block);
                }
                //prawo
                if((element%block_count)!=0){
                    check_clicked(element+1,block_array_pointer,buffer,standard_block,zero_block,one_block,two_block,three_block,four_block,five_block,six_block,seven_block,eight_block,bomb_block,bomb_2_block,bomb_3_block,flag_block);
                }
                //dol
                if((element+block_count)<(block_count*block_count)){
                        check_clicked(element+block_count,block_array_pointer,buffer,standard_block,zero_block,one_block,two_block,three_block,four_block,five_block,six_block,seven_block,eight_block,bomb_block,bomb_2_block,bomb_3_block,flag_block);
                   }
                //lewo
                if(element%block_count!=1){
                        check_clicked(element-1,block_array_pointer,buffer,standard_block,zero_block,one_block,two_block,three_block,four_block,five_block,six_block,seven_block,eight_block,bomb_block,bomb_2_block,bomb_3_block,flag_block);
                }
            }

        }

}


int main(void)
{
srand(time(NULL));
allegro_init();
install_keyboard();
install_mouse();
install_timer();


//allegro_message("This is the first allegro program (Press OK)");
set_color_depth(8);
if(set_gfx_mode(GFX_AUTODETECT_WINDOWED,800,600,0,0))
{
    allegro_message(allegro_error);
    exit(0);
}


//START_OF_BITMAP's - mozliwosc optymalizacji poprzez ładowanie tylko tych bitmat które będą potrzebne
BITMAP *standard_block = create_bitmap(25,25);//Stworzenie wirtualnego ekranu o rozmiarach 25,25
standard_block = load_bitmap("bitmaps/standard_block.bmp",NULL);//Ponieważ grafika zajmuje całą bitmape to nie trzeba jej czyścić.
BITMAP *zero_block = create_bitmap(25,25);
zero_block = load_bitmap("bitmaps/0_block.bmp",NULL);
BITMAP *one_block = create_bitmap(25,25);
one_block = load_bitmap("bitmaps/1_block.bmp",NULL);
BITMAP *two_block = create_bitmap(25,25);
two_block = load_bitmap("bitmaps/2_block.bmp",NULL);
BITMAP *three_block = create_bitmap(25,25);
three_block = load_bitmap("bitmaps/3_block.bmp",NULL);
BITMAP *four_block = create_bitmap(25,25);
four_block = load_bitmap("bitmaps/4_block.bmp",NULL);
BITMAP *five_block = create_bitmap(25,25);
five_block = load_bitmap("bitmaps/5_block.bmp",NULL);
BITMAP *six_block = create_bitmap(25,25);
six_block = load_bitmap("bitmaps/6_block.bmp",NULL);
BITMAP *seven_block = create_bitmap(25,25);
seven_block = load_bitmap("bitmaps/7_block.bmp",NULL);
BITMAP *eight_block = create_bitmap(25,25);
eight_block = load_bitmap("bitmaps/8_block.bmp",NULL);
BITMAP *bomb_block = create_bitmap(25,25);
bomb_block = load_bitmap("bitmaps/bomb_block.bmp",NULL);
BITMAP *bomb_2_block = create_bitmap(25,25);
bomb_2_block = load_bitmap("bitmaps/bomb2_block.bmp",NULL);
BITMAP *bomb_3_block = create_bitmap(25,25);
bomb_3_block = load_bitmap("bitmaps/bomb3_block.bmp",NULL);
BITMAP *flag_block = create_bitmap(25,25);
flag_block = load_bitmap("bitmaps/flag_block.bmp",NULL);
BITMAP *ramka_dol = create_bitmap(25,25);
ramka_dol = load_bitmap("bitmaps/ramka_dol.bmp",NULL);
BITMAP *ramka_dollewy = create_bitmap(25,25);
ramka_dollewy = load_bitmap("bitmaps/ramka_dollewy.bmp",NULL);
BITMAP *ramka_dolprawy = create_bitmap(25,25);
ramka_dolprawy = load_bitmap("bitmaps/ramka_dolprawy.bmp",NULL);
BITMAP *ramka_fill = create_bitmap(25,25);
ramka_fill = load_bitmap("bitmaps/ramka_fill.bmp",NULL);
BITMAP *ramka_gora = create_bitmap(25,25);
ramka_gora = load_bitmap("bitmaps/ramka_gora.bmp",NULL);
BITMAP *ramka_goralewy = create_bitmap(25,25);
ramka_goralewy = load_bitmap("bitmaps/ramka_goralewy.bmp",NULL);
BITMAP *ramka_goraprawy = create_bitmap(25,25);
ramka_goraprawy = load_bitmap("bitmaps/ramka_goraprawy.bmp",NULL);
BITMAP *ramka_lewy = create_bitmap(25,25);
ramka_lewy = load_bitmap("bitmaps/ramka_lewy.bmp",NULL);
BITMAP *ramka_prawy = create_bitmap(25,25);
ramka_prawy = load_bitmap("bitmaps/ramka_prawy.bmp",NULL);

BITMAP* buffer = create_bitmap(SCREEN_W, SCREEN_H);//Buffer czyli zastępczy wirutalny ekran na którym rysowana jest kolejna klatka - zapobiega migotaniu ekranu
clear(buffer);//Standardowa bitmapa nie jest wyczyszczona i może zawierać zbędny szum, dlatego należy ją wyczyścić0
//END_OF_BITMAPS



show_mouse(screen);
int *block_array_pointer = (int *)calloc((block_count*block_count)+1, sizeof(int)); //dynamiczna tablica przechowywująca stan bloku
// STANY_BLOKOW - {0-standardowy,1-jedna bomba...8-osiem bomb, >50-odsloniety block, >300-flaga, 15-bomba , 20-bomba zlikwidowana, 25-bomba zdetonowana}
wyzeruj_tablice(block_array_pointer,block_count);//poczatkowe zerowanie tablicy - kazdy blok ma stan rowny 0

clear(buffer);//Skoro juz przekopiowalismy plansze to mozemy ja wyczyscic aby skorzystac z tego pozniej
losuj_bomby(block_array_pointer,ilosc_bomb,block_count);
sprawdz_plansze(block_array_pointer,block_count);

draw_sprite(screen,buffer,0,0);//Gdy skonczymy wirtualny ekran, to rysujemy go do rzeczywistego - komputer nie liczy nabierząco każdego kwadrata tylko pokazuje się cała plansza

draw_sprite(buffer,ramka_goralewy,starting_x,starting_y);//Rog lewy gora
draw_sprite(buffer,ramka_goraprawy,starting_x+(block_size*block_count) + 25,starting_y);//Rog prawy gora
draw_sprite(buffer,ramka_dollewy,starting_x,starting_y+(block_size*block_count) + 75);//Rog lewy dol
draw_sprite(buffer,ramka_dolprawy,starting_x+(block_size*block_count) + 25,starting_y+(block_size*block_count) + 75);//Rog prawy gora

 int i=0;int j=0;int z=0;//Tymczasowe zmienne do petli
    for(i=0;i<block_count;i++){
        draw_sprite(buffer,ramka_gora,starting_x+(block_size*i) + 25,starting_y);//Ramka gora
        draw_sprite(buffer,ramka_dol,starting_x+(block_size*i) + 25,starting_y+(block_size*block_count) + 75);//Ramka dol
        draw_sprite(buffer,ramka_fill,starting_x+(block_size*i) + 25,starting_y + 25);//Wypelnienie
        draw_sprite(buffer,ramka_fill,starting_x+(block_size*i) + 25,starting_y + 50);//Wypelnienie
        for(z=0;z<block_count+2;z++)
            {
            draw_sprite(buffer,ramka_lewy,starting_x,starting_y+(block_size*z) + 25);//Ramka lewo
            draw_sprite(buffer,ramka_prawy,starting_x+(block_size*block_count) + 25,starting_y+(block_size*z) + 25);//Ramka prawo
            }
        for(j=0;j<block_count;j++){
            //rect(buffer,starting_x+(i*block_size),starting_y+(j*block_size),(starting_x+block_size)+(i*block_size),(starting_y+block_size)+(j*block_size),GREEN);//Pomocnicze rysowanie bloków gdy nie ma grafiki
            draw_sprite(buffer,standard_block,starting_x+(i*block_size) + 25,starting_y+(j*block_size) + 75);//Rysowanie grafiki wszystkich blokow do wirtualnego ekranu
        }
    }

draw_sprite(screen,buffer,0,0);
//odslon_wszystko(block_array_pointer,buffer,standard_block,zero_block,one_block,two_block,three_block,four_block,five_block,six_block,seven_block,eight_block,bomb_block,bomb_2_block,bomb_3_block,flag_block);
int x_cords;
int y_cords;
int element;
int flags=0;
while(!key[KEY_ESC])//Mozliwosc opuszczenia programu i petli klawiszem ESC
{


if(mouse_b&1){//Wykrycie klikniecia lewym przyciskiem myszki
    if((mouse_x<(starting_x+(block_size*block_count))&&(mouse_x>starting_x-1)&&(mouse_y<starting_y+(block_size*block_count))&&(mouse_y>starting_y-1))){ // IF zwraca prawdę gdy pozycja myszki znajduje się na planszy
        element = ((mouse_x-starting_x+block_size)/block_size)+(((mouse_y-starting_y)/block_size)*block_count);
        x_cords = ((element-1)%block_count)*block_size;
        y_cords = ((element - (element-1)%block_count)/block_count)*block_size;
        textprintf(screen,font,500,130,GREEN,"Numer x :%3d",x_cords); // wyswietla napis obecnie klikniętego bloku
        textprintf(screen,font,500,150,GREEN,"Numer y :%3d",y_cords); // wyswietla napis obecnie klikniętego bloku

        //odslon_kwadrat(element,block_array_pointer,buffer,standard_block,zero_block,one_block,two_block,three_block,four_block,five_block,six_block,seven_block,eight_block,bomb_block,bomb_2_block,bomb_3_block,flag_block);
        check_clicked(element,block_array_pointer,buffer,standard_block,zero_block,one_block,two_block,three_block,four_block,five_block,six_block,seven_block,eight_block,bomb_block,bomb_2_block,bomb_3_block,flag_block);
        draw_sprite(screen,buffer,0,0);
        clear(buffer);
        //check_clicked(box,block_array_pointer,buffer,standard_block,zero_block,one_block,two_block,three_block,four_block,five_block,six_block,seven_block,eight_block,bomb_block,bomb_2_block,bomb_3_block,flag_block);
    }
}
if(mouse_b&2){
    element = ((mouse_x-starting_x+block_size)/block_size)+(((mouse_y-starting_y)/block_size)*block_count);
    x_cords = ((element-1)%block_count)*block_size;
    y_cords = ((element - (element-1)%block_count)/block_count)*block_size;
    if(block_array_pointer[element]<50 && block_array_pointer[element]!=25&&block_array_pointer[element]!=20){
        draw_sprite(screen,flag_block,x_cords,y_cords);
        block_array_pointer[element]=block_array_pointer[element]+300;
        flags++;
    }else{
        if(block_array_pointer[element]>299){
            draw_sprite(screen,standard_block,x_cords,y_cords);
            block_array_pointer[element]=block_array_pointer[element]-300;
            flags--;
        }
    }
}
if(flags==ilosc_bomb){
    odslon_kwadrat(element,block_array_pointer,buffer,standard_block,zero_block,one_block,two_block,three_block,four_block,five_block,six_block,seven_block,eight_block,bomb_block,bomb_2_block,bomb_3_block,flag_block);
    draw_sprite(screen,buffer,0,0);
}



//Diagnostyczne informacje :
textprintf(screen,font,500,10,WHITE,"Screen Resolution %dx%d",SCREEN_W,SCREEN_H);
textprintf(screen,font,500,30,RED,"Mouse Pos x:y=%3d:%3d",mouse_x,mouse_y);
textprintf(screen,font,500,50,BLUE,"Mouse Scroll Pos: %3d",mouse_z);
textprintf(screen,font,500,70,GREEN,"Mouse Left Button Pressed:%3s",((mouse_b&1)?"Yes":"No"));
textprintf(screen,font,500,90,GREEN,"Mouse Right Button Pressed:%3s",((mouse_b&2)?"Yes":"No"));
textprintf(screen,font,500,110,GREEN,"Mouse Middle Button Pressed:%3s",((mouse_b&4)?"Yes":"No"));
textprintf(screen,font,650,170,GREEN,"Raw Mouse :%d",mouse_b);
}

free(block_array_pointer);
block_array_pointer = NULL;


destroy_bitmap(buffer);//Przed wyłączeniem programu zwalnia pamięć bitmapy.

allegro_exit();
return 0;
}
END_OF_MAIN();







